from pathlib import Path
import pickle

try:
    import joblib
except ModuleNotFoundError:
    joblib = None

model_path = Path(__file__).resolve().parent / "crop_model.pkl"

if not model_path.exists():
    raise FileNotFoundError(f"Model file not found: {model_path}")

if joblib is not None:
    try:
        model = joblib.load(model_path)
    except Exception:
        with model_path.open("rb") as f:
            model = pickle.load(f)
else:
    with model_path.open("rb") as f:
        model = pickle.load(f)

N = float(input("Enter Nitrogen: "))
P = float(input("Enter Phosphorus: "))
K = float(input("Enter Potassium: "))
temperature = float(input("Enter Temperature: "))
humidity = float(input("Enter Humidity: "))
ph = float(input("Enter pH value: "))
rainfall = float(input("Enter Rainfall: "))

sample = [[N, P, K, temperature, humidity, ph, rainfall]]

prediction = model.predict(sample)

print("Recommended Crop:", prediction[0])