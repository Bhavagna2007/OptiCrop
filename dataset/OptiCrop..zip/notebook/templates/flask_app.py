from flask import Flask, render_template, request
from pathlib import Path
import pickle
import pandas as pd

try:
    import joblib
except ModuleNotFoundError:
    joblib = None

base_dir = Path(__file__).resolve().parent
app = Flask(__name__, template_folder=str(base_dir))

model_path = base_dir.parent / "crop_model.pkl"
if not model_path.exists():
    raise FileNotFoundError(f"Model file not found: {model_path}")

if joblib is not None:
    try:
        model = joblib.load(model_path)
    except Exception:
        with model_path.open("rb") as f:
            model = pickle.load(f)
else:
    with model_path.open("rb") as f:
        model = pickle.load(f)

@app.route("/", methods=["GET", "POST"])
def home():

    prediction = ""

    if request.method == "POST":
        N = float(request.form["N"])
        P = float(request.form["P"])
        K = float(request.form["K"])
        temperature = float(request.form["temperature"])
        humidity = float(request.form["humidity"])
        ph = float(request.form["ph"])
        rainfall = float(request.form["rainfall"])

        sample = pd.DataFrame(
            [[N, P, K, temperature, humidity, ph, rainfall]],
            columns=[
                "N",
                "P",
                "K",
                "temperature",
                "humidity",
                "ph",
                "rainfall"
            ]
        )

        prediction = model.predict(sample)[0]

    return render_template(
        "index.html",
        prediction=prediction
    )

if __name__ == "__main__":
    app.run(debug=True)