from pathlib import Path
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

base_dir = Path(__file__).resolve().parent
csv_path = base_dir.parent / "Crop_recommendation.csv"
model_path = base_dir / "crop_model.pkl"

# Load dataset
# The CSV lives one folder above the notebook folder
# Example: .../dataset/Crop_recommendation.csv
data = pd.read_csv(csv_path)

# Prepare features and label
X = data.drop('label', axis=1)
y = data['label']

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X, y)

# Save model next to this script
joblib.dump(model, model_path)
print(f"Saved model to {model_path}")
